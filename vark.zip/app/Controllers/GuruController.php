<?php

namespace App\Controllers;

use App\Models\VarkSoalModel;

class GuruController extends BaseController
{
    // ======== DASHBOARD GURU ========
    public function dashboard()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'guru') {
            return redirect()->to('/login');
        }
        $data['title'] = 'Dashboard Guru';
        return view('guru/dashboard', $data);
    }

    // ======== HALAMAN KELOLA SOAL VARK (LIST) ========
    public function varkSoal()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'guru') {
            return redirect()->to('/login');
        }

        $model = new VarkSoalModel();
        $data['soal'] = $model->orderBy('nomor', 'ASC')->findAll();
        $data['title'] = 'Kelola Soal VARK';
        return view('guru/vark_soal', $data);
    }

    // ======== HALAMAN TAMBAH SOAL VARK ========
    public function varkSoalTambah()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'guru') {
            return redirect()->to('/login');
        }

        $model = new VarkSoalModel();
        $last = $model->orderBy('nomor', 'DESC')->first();
        $nextNomor = $last ? $last['nomor'] + 1 : 1;

        $data = [
            'title' => 'Tambah Soal VARK',
            'nomor' => $nextNomor,
        ];
        return view('guru/vark_soal_tambah', $data);
    }

    // ======== PROSES SIMPAN SOAL VARK ========
    public function varkSoalSimpan()
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'guru') {
            return redirect()->to('/login');
        }

        $model = new VarkSoalModel();

        // Ambil data dari POST
        $nomor = $this->request->getPost('nomor');
        $teks_soal = $this->request->getPost('teks_soal');
        $opsi_v = $this->request->getPost('opsi_v');
        $opsi_a = $this->request->getPost('opsi_a');
        $opsi_r = $this->request->getPost('opsi_r');
        $opsi_k = $this->request->getPost('opsi_k');

        // Validasi manual
        if (empty($teks_soal) || empty($opsi_v) || empty($opsi_a) || empty($opsi_r) || empty($opsi_k)) {
            return redirect()->to('/guru/vark/soal/tambah')
                             ->with('error', 'Semua field wajib diisi!');
        }

        // Cek apakah nomor sudah ada
        $cek = $model->where('nomor', $nomor)->first();
        if ($cek) {
            return redirect()->to('/guru/vark/soal/tambah')
                             ->with('error', 'Nomor soal sudah digunakan!');
        }

        // Simpan
        $model->save([
            'nomor' => $nomor,
            'teks_soal' => $teks_soal,
            'opsi_v' => $opsi_v,
            'opsi_a' => $opsi_a,
            'opsi_r' => $opsi_r,
            'opsi_k' => $opsi_k,
        ]);

        return redirect()->to('/guru/vark/soal')->with('success', 'Soal berhasil ditambahkan!');
    }

    // ======== HALAMAN EDIT SOAL VARK ========
    public function varkSoalEdit($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'guru') {
            return redirect()->to('/login');
        }

        $model = new VarkSoalModel();
        $data['soal'] = $model->find($id);

        if (!$data['soal']) {
            return redirect()->to('/guru/vark/soal')->with('error', 'Soal tidak ditemukan!');
        }

        $data['title'] = 'Edit Soal VARK';
        return view('guru/vark_soal_edit', $data);
    }

    // ======== PROSES UPDATE SOAL VARK ========
    public function varkSoalUpdate($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'guru') {
            return redirect()->to('/login');
        }

        $model = new VarkSoalModel();

        $teks_soal = $this->request->getPost('teks_soal');
        $opsi_v = $this->request->getPost('opsi_v');
        $opsi_a = $this->request->getPost('opsi_a');
        $opsi_r = $this->request->getPost('opsi_r');
        $opsi_k = $this->request->getPost('opsi_k');

        if (empty($teks_soal) || empty($opsi_v) || empty($opsi_a) || empty($opsi_r) || empty($opsi_k)) {
            return redirect()->to('/guru/vark/soal/edit/' . $id)
                             ->with('error', 'Semua field wajib diisi!');
        }

        $model->update($id, [
            'teks_soal' => $teks_soal,
            'opsi_v' => $opsi_v,
            'opsi_a' => $opsi_a,
            'opsi_r' => $opsi_r,
            'opsi_k' => $opsi_k,
        ]);

        return redirect()->to('/guru/vark/soal')->with('success', 'Soal berhasil diupdate!');
    }

    // ======== HAPUS SOAL VARK ========
    public function varkSoalHapus($id)
    {
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'guru') {
            return redirect()->to('/login');
        }

        $model = new VarkSoalModel();
        $model->delete($id);

        return redirect()->to('/guru/vark/soal')->with('success', 'Soal berhasil dihapus!');
    }
}