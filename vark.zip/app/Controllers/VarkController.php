<?php

namespace App\Controllers;

use App\Models\VarkResultModel;

class VarkController extends BaseController
{
    // Data soal VARK (10 soal sesuai Lampiran 3.1)
    private $questions = [
        1 => 'Ketika guru menjelaskan materi Biologi tentang sistem pernapasan manusia, cara yang paling membantu saya memahami materi tersebut adalah …',
        2 => 'Saat saya harus mempersiapkan diri menghadapi ulangan, saya biasanya lebih mudah belajar dengan cara …',
        3 => 'Guru Biologi sedang menjelaskan cara kerja jantung manusia di depan kelas. Agar kamu paling cepat paham, apa yang sebaiknya guru tersebut lakukan?',
        4 => 'Kelompokmu mendapat tugas membuat proyek mading atau presentasi tentang Sejarah Kemerdekaan. Saat diskusi pembagian tugas, peran apa yang paling ingin kamu ambil?',
        5 => 'Jika saya mengalami kesulitan memahami suatu konsep pelajaran, hal pertama yang biasanya saya lakukan adalah …',
        6 => 'Besok ada ujian sekolah dan kamu harus belajar materi yang cukup banyak. Cara belajar seperti apa yang biasanya kamu lakukan di rumah?',
        7 => 'Ketika mempelajari konsep abstrak yang sulit dibayangkan (misalnya mekanisme kerja organ atau proses biologis), saya paling mudah memahami materi jika …',
        8 => 'Kamu mengikuti ekstrakurikuler (misalnya basket, tari, atau musik) dan pelatih mengajarkan teknik gerakan baru. Bagaimana caramu agar bisa cepat menirunya?',
        9 => 'Ketika harus menerapkan materi pelajaran untuk menyelesaikan soal atau masalah baru, saya biasanya …',
        10 => 'Saat jam pelajaran praktikum di laboratorium, guru meminta kamu merangkai alat percobaan. Apa yang pertama kali kamu lakukan?'
    ];

    private $options = [
        'V' => [
            1 => 'Melihat gambar, diagram, atau video yang menunjukkan struktur dan proses sistem pernapasan.',
            2 => 'Membuat atau melihat peta konsep, bagan, atau warna-warna penanda materi pelajaran.',
            3 => 'Menunjukkan poster gambar anatomi jantung atau diagram alur peredaran darah di papan tulis/layar proyektor.',
            4 => 'Bagian desain & tata letak: Mengatur posisi gambar, memilih warna, dan membuat grafik/peta konsep agar terlihat menarik.',
            5 => 'Mencari gambar, diagram, atau video yang menjelaskan konsep tersebut.',
            6 => 'Membuat peta pikiran, diagram, atau memberi warna-warni stabilo pada poin-poin penting di catatanmu.',
            7 => 'Konsep tersebut disajikan dalam visualisasi bertahap (diagram alur, skema proses, animasi) sehingga saya dapat melihat hubungan antarbagian.',
            8 => 'Melihat gambar sketsa formasi atau diagram langkah kaki yang digambar pelatih di papan strategi.',
            9 => 'Membayangkan diagram, skema, atau pola visual yang berkaitan dengan masalah tersebut.',
            10 => 'Mengamati gambar diagram alur atau skema rangkaian yang ada di papan tulis.'
        ],
        'A' => [
            1 => 'Mendengarkan penjelasan lisan guru dan diskusi di kelas.',
            2 => 'Mengulang materi dengan mendengarkan penjelasan guru, teman, atau rekaman suara.',
            3 => 'Menjelaskan secara lisan dengan bercerita atau mengadakan sesi tanya jawab langsung dengan siswa.',
            4 => 'Bagian juru bicara: Mempresentasikan hasil diskusi di depan kelas atau memimpin diskusi kelompok.',
            5 => 'Bertanya dan mendengarkan penjelasan guru atau teman.',
            6 => 'Belajar sambil berdiskusi dengan teman lewat telepon, atau membaca materi dengan suara keras.',
            7 => 'Guru menjelaskan secara lisan langkah demi langkah, disertai contoh analogi yang dapat saya dengarkan.',
            8 => 'Mendengarkan aba-aba dan penjelasan pelatih dengan saksama sebelum mencoba.',
            9 => 'Mengingat kembali penjelasan lisan atau diskusi yang pernah saya dengar terkait materi itu.',
            10 => 'Menunggu instruksi lisan guru atau bertanya kepada teman kelompok: "Ini yang mana dulu yang dipasang?"'
        ],
        'R' => [
            1 => 'Membaca buku teks atau rangkuman tertulis, kemudian mencatat poin-poin penting.',
            2 => 'Membaca ulang catatan dan buku pelajaran, lalu menuliskannya kembali dengan bahasa sendiri.',
            3 => 'Memberikan lembaran materi atau menyuruh siswa membaca buku paket yang menjelaskan rincian prosesnya secara tertulis.',
            4 => 'Bagian penulis konten: Mencari referensi dari buku/internet, lalu menuliskan naskah atau ringkasan materinya.',
            5 => 'Membaca kembali buku pelajaran atau catatan hingga saya paham.',
            6 => 'Membaca ulang catatan buku tulis berulang-ulang atau menulis ringkasan materi menggunakan kalimat sendiri.',
            7 => 'Saya dapat membaca penjelasan tertulis secara runtut, kemudian menuliskan kembali konsep tersebut dengan kata-kata saya sendiri.',
            8 => 'Membaca buku panduan aturan atau catatan instruksi teknik yang diberikan.',
            9 => 'Merujuk pada langkah-langkah tertulis atau rumus yang saya baca dan pahami sebelumnya.',
            10 => 'Membaca langkah-langkah kerja (LKS) atau modul penuntun praktikum dengan teliti.'
        ],
        'K' => [
            1 => 'Mengikuti praktikum, simulasi, atau aktivitas langsung yang melibatkan pernapasan.',
            2 => 'Belajar sambil mempraktikkan, mencoba contoh soal langsung, atau belajar sambil bergerak.',
            3 => 'Membawa model patung jantung (torso) ke kelas agar bisa dipegang dan dibongkar-pasang oleh siswa.',
            4 => 'Bagian perlengkapan & perakitan: Menggunting, menempel, atau membuat properti fisik/maket yang dibutuhkan.',
            5 => 'Mencoba mempraktikkan konsep tersebut melalui contoh atau kegiatan nyata.',
            6 => 'Mengerjakan latihan soal atau menirukan/mempraktikkan kejadian (roleplay) dari materi yang dipelajari.',
            7 => 'Saya diberi kesempatan untuk mengaitkan konsep dengan pengalaman nyata atau aktivitas simulatif, sehingga saya dapat "merasakan" prosesnya.',
            8 => 'Memperhatikan contoh gerakan pelatih lalu langsung ikut mempraktikkannya berulang-ulang dengan tubuhmu sendiri.',
            9 => 'Memikirkan bagaimana masalah tersebut dapat diselesaikan melalui tindakan atau simulasi nyata.',
            10 => 'Langsung memegang alat-alatnya dan mencoba merangkainya sendiri sambil jalan (trial and error).'
        ]
    ];

    // ======== HALAMAN INTRO VARK (Page 3) ========
    public function index()
    {
        // Cek login
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'siswa') {
            return redirect()->to('/login');
        }

        // Cek apakah sudah pernah mengerjakan VARK
        $model = new VarkResultModel();
        $existing = $model->where('pengguna_id', session()->get('user_id'))->first();

        if ($existing) {
            // Jika sudah, arahkan ke halaman pilih modul dengan pesan
            return redirect()->to('/siswa/modul')->with('info', 'Anda sudah mengerjakan tes VARK. Hasil: ' . $existing['kategori_hasil']);
        }

        $data['title'] = 'Tes VARK - Sistem Adaptif';
        return view('vark/intro', $data);
    }

    // ======== HALAMAN SOAL VARK (Page 4) ========
    public function soal()
    {
        // Cek login
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'siswa') {
            return redirect()->to('/login');
        }

        // Cek apakah sudah pernah mengerjakan VARK
        $model = new VarkResultModel();
        $existing = $model->where('pengguna_id', session()->get('user_id'))->first();
        if ($existing) {
            return redirect()->to('/siswa/modul')->with('info', 'Anda sudah mengerjakan tes VARK.');
        }

        $data = [
            'title' => 'Soal Tes VARK',
            'questions' => $this->questions,
            'options' => $this->options
        ];
        return view('vark/soal', $data);
    }

    // ======== PROSES SUBMIT VARK ========
    public function submit()
    {
        // Cek login
        if (!session()->get('isLoggedIn') || session()->get('role') !== 'siswa') {
            return redirect()->to('/login');
        }

        $answers = $this->request->getPost('answers');

        // Validasi: harus ada 10 jawaban
        if (!$answers || count($answers) !== 10) {
            return redirect()->to('/vark/soal')->with('error', 'Silakan jawab semua pertanyaan!');
        }

        // Klasifikasi menggunakan helper
        $result = classify_vark($answers);

        // Simpan ke database
        $model = new VarkResultModel();
        $model->save([
            'pengguna_id'    => session()->get('user_id'),
            'skor_v'         => $result['scores']['V'],
            'skor_a'         => $result['scores']['A'],
            'skor_r'         => $result['scores']['R'],
            'skor_k'         => $result['scores']['K'],
            'selisih'        => $result['delta'],
            'kategori_hasil' => $result['label'],
            'tipe_hasil'     => $result['type']
        ]);

        // Tampilkan halaman hasil
        $data = [
            'title' => 'Hasil Tes VARK',
            'result' => $result,
            'nama' => session()->get('name')
        ];
        return view('vark/hasil', $data);
    }
}