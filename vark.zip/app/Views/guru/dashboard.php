<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-12">
        <!-- KARTU STATISTIK (DARI KODE LAMA) -->
        <div class="card card-shadow p-4">
            <h2>👨‍🏫 Halo, Guru <?= session()->get('name') ?></h2>
            <p class="text-muted">Dashboard monitoring siswa.</p>
            <hr>
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card border-primary p-3">
                        <h5><i class="fas fa-users text-primary"></i> Total Siswa</h5>
                        <h3>0</h3>
                        <small class="text-muted">Belum ada data</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-success p-3">
                        <h5><i class="fas fa-check-circle text-success"></i> Tuntas VARK</h5>
                        <h3>0</h3>
                        <small class="text-muted">Belum ada data</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-danger p-3">
                        <h5><i class="fas fa-exclamation-triangle text-danger"></i> Perlu Intervensi</h5>
                        <h3>0</h3>
                        <small class="text-muted">Belum ada data</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- MENU KELOLA SOAL (DARI KODE BARU) -->
        <div class="card card-shadow p-4 mt-4">
            <h4 class="fw-bold mb-3"><i class="fas fa-cogs text-primary me-2"></i>Menu Kelola</h4>
            <hr>
            <div class="row mt-3">
                <!-- Kelola Soal VARK -->
                <div class="col-md-4 mb-3">
                    <div class="card border-primary h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-list-ul fa-3x text-primary mb-3"></i>
                            <h5>Kelola Soal VARK</h5>
                            <p class="text-muted small">Tambah, edit, atau hapus soal VARK</p>
                            <a href="<?= base_url('guru/vark/soal') ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-arrow-right"></i> Kelola
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Lihat Hasil VARK Siswa -->
                <div class="col-md-4 mb-3">
                    <div class="card border-success h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-chart-bar fa-3x text-success mb-3"></i>
                            <h5>Hasil VARK Siswa</h5>
                            <p class="text-muted small">Lihat gaya belajar siswa</p>
                            <a href="#" class="btn btn-success btn-sm">
                                <i class="fas fa-arrow-right"></i> Lihat
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Kelola Soal ZPD -->
                <div class="col-md-4 mb-3">
                    <div class="card border-warning h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-flask fa-3x text-warning mb-3"></i>
                            <h5>Kelola Soal ZPD</h5>
                            <p class="text-muted small">Kelola soal ZPD per modul</p>
                            <a href="#" class="btn btn-warning btn-sm">
                                <i class="fas fa-arrow-right"></i> Kelola
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>