<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-12">
        <div class="card card-shadow p-4">
            <h2>👋 Halo, <?= session()->get('name') ?></h2>
            <p class="text-muted">Selamat datang di dashboard siswa.</p>
            <hr>
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card bg-primary text-white p-3">
                        <h5><i class="fas fa-pencil-alt"></i> Tes VARK</h5>
                        <p>Cari tahu gaya belajarmu!</p>
                        <a href="#" class="btn btn-light btn-sm">Mulai</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-success text-white p-3">
                        <h5><i class="fas fa-flask"></i> Tes ZPD</h5>
                        <p>Ukur level kemampuanmu.</p>
                        <a href="#" class="btn btn-light btn-sm">Mulai</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-warning text-dark p-3">
                        <h5><i class="fas fa-book"></i> Modul Belajar</h5>
                        <p>Mulai pembelajaran adaptif.</p>
                        <a href="<?= base_url('siswa/modul') ?>" class="btn btn-light btn-sm">
                            <i class="fas fa-book me-1"></i> Lihat Modul
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>