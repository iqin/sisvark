<?php

namespace App\Models;

use CodeIgniter\Model;

class VarkSoalModel extends Model
{
    protected $table         = 'vark_soal';
    protected $primaryKey    = 'id';
    
    // Field yang boleh diisi (tidak termasuk created_at & updated_at)
    protected $allowedFields = ['nomor', 'teks_soal', 'opsi_v', 'opsi_a', 'opsi_r', 'opsi_k'];
    
    // Aktifkan timestamps otomatis
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
}